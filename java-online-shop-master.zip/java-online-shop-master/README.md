# Online shop implemented in Java. 

# A customer can: 
 - add a product to the shopping cart
 - subscribe to get notifications about a product he likes
 - add a product to the wishlist
 - get a suggestion about a product he might like. 


# You can also:
 - add products to the shop
 - remove products from the shop
 - edit a product price or name
