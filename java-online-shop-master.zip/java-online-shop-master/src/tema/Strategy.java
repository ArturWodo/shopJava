package tema;



public interface Strategy {
	public Item execute(Wishlist wishlist);
}
