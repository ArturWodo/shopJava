package tema;


public interface Observer {
	public void update(Notification n);
}
